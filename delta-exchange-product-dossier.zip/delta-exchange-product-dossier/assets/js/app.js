(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const header = document.querySelector('[data-header]');
  const menuButton = document.querySelector('[data-menu-button]');
  const mobileMenu = document.querySelector('[data-mobile-menu]');
  const progress = document.querySelector('.reading-progress span');
  const topButton = document.querySelector('[data-back-to-top]');
  const sectionName = document.querySelector('[data-section-name]');

  const updateScrollUi = () => {
    const y = window.scrollY;
    header?.classList.toggle('scrolled', y > 30);
    topButton?.classList.toggle('visible', y > 900);
    if (progress) {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = `${max > 0 ? Math.min(100, (y / max) * 100) : 0}%`;
    }
    if (!reduceMotion) {
      document.documentElement.style.setProperty('--scroll-y', `${y}px`);
      document.querySelectorAll('.hero-orbit').forEach((orb, index) => {
        orb.style.transform = `translate3d(0, ${y * (index ? .055 : .035)}px, 0) rotate(${y * .012}deg)`;
      });
    }
  };
  updateScrollUi();
  window.addEventListener('scroll', updateScrollUi, { passive: true });

  if (menuButton && mobileMenu) {
    menuButton.addEventListener('click', () => {
      const open = mobileMenu.classList.toggle('open');
      document.body.classList.toggle('menu-open', open);
      menuButton.setAttribute('aria-expanded', String(open));
    });
    mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
      document.body.classList.remove('menu-open');
      menuButton.setAttribute('aria-expanded', 'false');
    }));
  }

  topButton?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }));

  document.querySelectorAll('[data-copy-link]').forEach(button => {
    button.addEventListener('click', async () => {
      const original = button.textContent;
      try {
        await navigator.clipboard.writeText(window.location.href);
        button.textContent = 'Link copied';
      } catch {
        window.prompt('Copy this page link:', window.location.href);
      }
      window.setTimeout(() => { button.textContent = original; }, 1600);
    });
  });

  const title = document.querySelector('[data-split-text]');
  if (title && !reduceMotion) {
    const words = title.textContent.trim().split(/\s+/);
    title.innerHTML = words.map((word, index) => `<span class="word"><span class="word-inner" style="animation-delay:${.12 + index * .11}s">${word}</span></span>`).join(' ');
  }

  const revealItems = document.querySelectorAll('.reveal');
  if (reduceMotion) {
    revealItems.forEach(el => el.classList.add('visible'));
  } else {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: .08 });
    revealItems.forEach((el, i) => {
      el.style.transitionDelay = `${Math.min((i % 4) * .05, .15)}s`;
      revealObserver.observe(el);
    });
  }

  const sections = [...document.querySelectorAll('[data-section]')];
  if (sections.length && sectionName) {
    const sectionObserver = new IntersectionObserver(entries => {
      const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) sectionName.textContent = visible.target.dataset.section;
    }, { threshold: [.2, .45, .7], rootMargin: '-25% 0px -55% 0px' });
    sections.forEach(section => sectionObserver.observe(section));
  }

  const countElements = document.querySelectorAll('[data-count]');
  const countObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = Number(el.dataset.count || 0);
      const decimals = Number(el.dataset.decimals || 0);
      const suffix = el.dataset.suffix || '';
      if (reduceMotion) {
        el.textContent = target.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }) + suffix;
      } else {
        const started = performance.now();
        const duration = 1200;
        const animate = now => {
          const t = Math.min(1, (now - started) / duration);
          const eased = 1 - Math.pow(1 - t, 4);
          const value = target * eased;
          el.textContent = value.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }) + suffix;
          if (t < 1) requestAnimationFrame(animate);
        };
        requestAnimationFrame(animate);
      }
      countObserver.unobserve(el);
    });
  }, { threshold: .5 });
  countElements.forEach(el => countObserver.observe(el));

  const metrics = window.DOSSIER_METRICS;
  const ratingChart = document.querySelector('[data-rating-chart]');
  if (ratingChart && metrics) {
    const max = Math.max(...metrics.ratingDistribution.map(row => row.count));
    ratingChart.innerHTML = metrics.ratingDistribution.map(row => `
      <div class="rating-column">
        <strong>${row.share.toFixed(1)}%</strong>
        <i class="rating-bar" style="height:${Math.max(5, (row.count / max) * 100)}%"></i>
        <span>${row.stars} star${row.stars > 1 ? 's' : ''}</span>
      </div>`).join('');
    const obs = new IntersectionObserver(entries => entries.forEach(e => {
      if (e.isIntersecting) { ratingChart.classList.add('visible'); obs.disconnect(); }
    }), { threshold: .35 });
    obs.observe(ratingChart);
  }

  const complaintChart = document.querySelector('[data-complaint-chart]');
  if (complaintChart && metrics) {
    const max = Math.max(...metrics.complaintThemes.map(row => row.value));
    complaintChart.innerHTML = metrics.complaintThemes.map(row => `
      <div class="complaint-row">
        <label>${row.label}</label>
        <div class="complaint-track"><i style="width:${(row.value / max) * 100}%"></i></div>
        <strong>${row.value.toFixed(1)}%</strong>
      </div>`).join('');
    const obs = new IntersectionObserver(entries => entries.forEach(e => {
      if (e.isIntersecting) { complaintChart.classList.add('visible'); obs.disconnect(); }
    }), { threshold: .25 });
    obs.observe(complaintChart);
  }

  document.querySelectorAll('.data-card').forEach(card => {
    const obs = new IntersectionObserver(entries => entries.forEach(e => {
      if (e.isIntersecting) { card.classList.add('visible'); obs.disconnect(); }
    }), { threshold: .35 });
    obs.observe(card);
  });

  if (!reduceMotion && window.matchMedia('(pointer:fine)').matches) {
    document.querySelectorAll('.magnetic').forEach(button => {
      button.addEventListener('pointermove', event => {
        const rect = button.getBoundingClientRect();
        const x = (event.clientX - rect.left - rect.width / 2) * .12;
        const y = (event.clientY - rect.top - rect.height / 2) * .12;
        button.style.transform = `translate(${x}px, ${y}px)`;
      });
      button.addEventListener('pointerleave', () => { button.style.transform = ''; });
    });
  }
})();
