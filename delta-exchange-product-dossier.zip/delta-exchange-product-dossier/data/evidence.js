window.EVIDENCE_DATA = [
  {
    id: 'E-001', category: 'Demand', status: 'Dataset', confidence: 'High',
    claim: 'The review corpus shows meaningful product-market fit rather than broad rejection.',
    summary: 'Across 22,199 public Google Play reviews, 65.7% are rated four or five stars. Positive reviews repeatedly value India-oriented derivatives access, INR convenience, charting and an approachable interface.',
    source: 'App Review Intelligence Report — pages 3 and 11',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=3',
    counter: 'Review data is self-selected and the export may not represent every review, language or user cohort.',
    implication: 'Preserve the core derivatives and INR proposition. The strategic task is to strengthen trust, not reinvent the category.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-002', category: 'Dataset quality', status: 'Dataset', confidence: 'High',
    claim: 'The average star rating hides a polarized and noisy review distribution.',
    summary: 'The sample average is 3.69/5, while 78.4% of reviews are either one star or five stars. 40.7% of the corpus is repeated-text excess and 53.3% of reviews contain three words or fewer.',
    source: 'App Review Intelligence Report — pages 1, 4 and 5',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=4',
    counter: 'Repeated or short text does not prove manipulation; it only lowers the qualitative information value of those rows.',
    implication: 'Weight detailed reviews, helpful votes and version patterns more heavily than the headline average.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-003', category: 'Fees', status: 'Dataset', confidence: 'High',
    claim: 'Fees, brokerage and deductions are the largest recurring theme in meaningful negative reviews.',
    summary: 'Among 4,882 meaningful one- and two-star reviews, 30.4% mention fees, brokerage or deductions.',
    source: 'App Review Intelligence Report — page 8',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=8',
    counter: 'A complaint about high fees may reflect price sensitivity or misunderstanding rather than inadequate disclosure.',
    implication: 'Test a contextual all-in cost and break-even preview inside the trade flow.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-004', category: 'Fees', status: 'Verified', confidence: 'High',
    claim: 'Delta already documents fees and provides calculation tools.',
    summary: 'Official fee pages document trading fees, GST, option fee caps and a fee calculator. The defensible gap is not “hidden fees,” but cognitive fragmentation at the moment of decision.',
    source: 'Delta Exchange India fee documentation',
    url: 'https://www.delta.exchange/fees',
    counter: 'A separate calculator may already meet the needs of informed traders, and some users may simply consider the price unattractive.',
    implication: 'Measure comprehension and decision quality rather than claiming that charges are concealed.',
    updated: '20 Jul 2026'
  },
  {
    id: 'E-005', category: 'Reliability', status: 'Dataset', confidence: 'Medium-High',
    claim: 'Reliability concerns become more consequential when they overlap with orders, charts and account state.',
    summary: 'In meaningful negative reviews, lag/freezing appears in 18.2%, P&L or balance issues in 17.9%, orders/execution in 16.4%, and charts/prices in 11.7%. These themes frequently co-occur.',
    source: 'App Review Intelligence Report — pages 8 and 9',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=8',
    counter: 'Review text cannot establish whether each event was caused by Delta, the user’s device, network conditions, market liquidity or expected order mechanics.',
    implication: 'Treat performance and observability as financial-risk controls, not ordinary app polish.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-006', category: 'Reliability', status: 'Verified', confidence: 'High',
    claim: 'Delta documents scheduled maintenance states and advance notification.',
    summary: 'The official maintenance guide states that users are notified 24–72 hours in advance and that trading, deposits, withdrawals and most API access are suspended during maintenance.',
    source: 'Delta Exchange India — maintenance guide',
    url: 'https://www.delta.exchange/support/solutions?articleId=80001132383&categoryId=null&folderId=null',
    counter: 'Advance notice may mean the primary problem is attention, risk tolerance or market gaps rather than missing functionality.',
    implication: 'Explore a focused maintenance-risk summary and position-preparation workflow without implying maintenance losses are common.',
    updated: '20 Jul 2026'
  },
  {
    id: 'E-007', category: 'API', status: 'Verified', confidence: 'High',
    claim: 'Delta has a mature public automation foundation.',
    summary: 'The API supports REST and WebSocket workflows for market data, account state and orders, with documented authentication, throttling, SDKs, a dead-man switch and a public system-status channel.',
    source: 'Delta Exchange API documentation',
    url: 'https://docs.delta.exchange/',
    counter: 'Public documentation establishes available interfaces, not adoption, production reliability or user comprehension.',
    implication: 'Build safety and observability experiments on top of the existing automation stack rather than proposing another disconnected tool.',
    updated: '23 Jul 2026'
  },
  {
    id: 'E-008', category: 'Execution', status: 'Dataset', confidence: 'Medium',
    claim: 'Execution-related complaints attract unusually high engagement.',
    summary: 'Orders, execution, stop-loss and slippage appear in 16.4% of meaningful negative reviews and average 8.3 helpful votes per review—higher than the more frequent fee category.',
    source: 'App Review Intelligence Report — page 8',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=8',
    counter: 'Helpful votes measure resonance, not truth. Review allegations are not authenticated incident records.',
    implication: 'Prioritise event reconstruction and explanation, while avoiding public claims of proven execution defects.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-009', category: 'Execution', status: 'Verified', confidence: 'High',
    claim: 'Official documentation confirms that liquidation and stop outcomes depend on several interacting mechanics.',
    summary: 'Mark price, margin mode, maintenance margin, trigger configuration, liquidity and partial-liquidation logic can all affect the final outcome.',
    source: 'Delta fair-price, margin and liquidation documentation',
    url: 'https://guides.delta.exchange/delta-exchange-india-user-guide/trading-guide/fair-price-marking',
    counter: 'Delta already provides a trading calculator and liquidation documentation; the opportunity is consolidation and contextual explanation, not claiming those tools are absent.',
    implication: 'Create a Liquidation Safety Centre that explains and reconstructs events using authoritative data.',
    updated: '20 Jul 2026'
  },
  {
    id: 'E-010', category: 'Support', status: 'Dataset', confidence: 'High',
    claim: 'Delta replies publicly to a high share of app reviews.',
    summary: 'The observed developer reply rate is 87.2%, including 81.5% of one-star reviews.',
    source: 'App Review Intelligence Report — page 13',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=13',
    counter: 'Reply coverage is an activity measure and does not prove resolution quality.',
    implication: 'Shift the support KPI from “replied” to “resolved with evidence.”',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-011', category: 'Support', status: 'Dataset', confidence: 'High',
    claim: 'Public support replies show signs of repetition and slow response for high-stakes complaints.',
    summary: 'Median observed reply delay is roughly 33 hours, the 90th percentile is roughly 102 hours, and repeated-reply excess equals 42.6% of replied rows.',
    source: 'App Review Intelligence Report — page 13',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=13',
    counter: 'App-review response time is not the same as private ticket SLA or resolution time.',
    implication: 'Use case-specific public replies that reference an evidence trail, case status and next action.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-012', category: 'Feature demand', status: 'Dataset', confidence: 'Medium-High',
    claim: 'Price alerts and mobile order-management controls show concentrated user demand.',
    summary: 'Price/chart alerts have 63 direct matches but 1,492 helpful votes. Drag-and-drop mobile SL/TP has 97 matches and 1,113 helpful votes.',
    source: 'App Review Intelligence Report — page 12',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=12',
    counter: 'Review requests are self-selected and do not replace product analytics or usability testing.',
    implication: 'After trust foundations, alerts and mobile SL/TP are strong retention-layer candidates.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-013', category: 'Product', status: 'Dataset', confidence: 'Medium-High',
    claim: 'Constructive high-rated reviews indicate retained goodwill.',
    summary: 'Some four- and five-star reviewers report serious bugs while retaining a positive rating, suggesting they want the product to improve rather than leave the category.',
    source: 'App Review Intelligence Report — page 11',
    url: 'downloads/delta-exchange-app-review-intelligence.pdf#page=11',
    counter: 'This is an interpretation of review behaviour, not a measured retention cohort.',
    implication: 'Visible reliability improvements and shipped feature requests could convert constructive users into advocates.',
    updated: '22 Jul 2026'
  },
  {
    id: 'E-014', category: 'Legal', status: 'Verified', confidence: 'High',
    claim: 'Delta Exchange India is presented as an India-specific platform operated by Excelium Technologies Private Limited and registered with FIU-IND.',
    summary: 'Official support and terms identify the operating entity and FIU reporting-entity registration. FIU registration is an AML/KYC status, not equivalent to SEBI or RBI product approval.',
    source: 'Delta Exchange India terms and support disclosures',
    url: 'https://www.delta.exchange/terms-of-use',
    counter: 'Regulatory language and product treatment can change; legal and tax interpretation require professional advice.',
    implication: 'Use precise language: “FIU-IND registered reporting entity,” not broad claims of conventional exchange regulation.',
    updated: '20 Jul 2026'
  },
  {
    id: 'E-015', category: 'Hypothesis', status: 'Hypothesis', confidence: 'High',
    claim: 'An all-in cost and break-even preview could improve decision comprehension.',
    summary: 'The hypothesis combines documented fee complexity with the largest negative review theme.',
    source: 'Synthesis of E-003 and E-004',
    url: 'index.html#opportunities',
    counter: 'The intervention may not change behaviour if users already understand the fees and simply dislike the price.',
    implication: 'Run a task-based comprehension test before committing to a full build.',
    updated: '23 Jul 2026'
  },
  {
    id: 'E-016', category: 'Hypothesis', status: 'Hypothesis', confidence: 'Medium',
    claim: 'A server-authoritative execution evidence receipt could improve dispute diagnosis and trust.',
    summary: 'The proposed receipt would show submission, trigger, market state, matching, fills, fees and balance reconciliation in one trace.',
    source: 'Synthesis of E-005, E-008 and E-009',
    url: 'index.html#integrity-receipt',
    counter: 'A timeline may diagnose disputes without reducing incident rates, and public exposure may create complexity or security constraints.',
    implication: 'Prototype for a narrow set of order types and measure support resolution and comprehension.',
    updated: '23 Jul 2026'
  },
  {
    id: 'E-017', category: 'Hypothesis', status: 'Hypothesis', confidence: 'Medium-High',
    claim: 'A high-volatility protection experience could reduce uncertainty during degraded conditions.',
    summary: 'The concept combines proactive status, data freshness, position visibility and constrained emergency actions during volatility or maintenance.',
    source: 'Synthesis of E-005, E-006 and E-007',
    url: 'index.html#opportunities',
    counter: 'There is no representative incident series proving how often users face this problem or which intervention would work best.',
    implication: 'Test comprehension and action completion during simulated degraded states.',
    updated: '23 Jul 2026'
  },
  {
    id: 'E-018', category: 'Rejected', status: 'Rejected', confidence: 'Low',
    claim: 'Public reviews prove that Delta manipulates prices or executes unauthorized orders.',
    summary: 'The reviewed public evidence contains allegations but no authenticated order logs, independent tick reconstruction or representative incident sample.',
    source: 'Adversarial Review and Citation Audit — pages 3–6',
    url: 'downloads/delta-exchange-adversarial-audit.pdf#page=3',
    counter: 'Verified internal logs or independent event-level reconstruction could materially change this assessment.',
    implication: 'Do not publish defect, fraud or prevalence claims from review allegations.',
    updated: '20 Jul 2026'
  },
  {
    id: 'E-019', category: 'Rejected', status: 'Rejected', confidence: 'Low',
    claim: 'Withdrawal failures or support failures are widespread.',
    summary: 'The evidence includes mixed anecdotes and no representative denominator, cause taxonomy or elapsed-time distribution.',
    source: 'Adversarial Review and Citation Audit — pages 3, 5 and 6',
    url: 'downloads/delta-exchange-adversarial-audit.pdf#page=3',
    counter: 'Anonymised support and withdrawal-state data could establish prevalence and root causes.',
    implication: 'Treat a withdrawal recovery hub as a discovery pilot, not a justified priority build.',
    updated: '20 Jul 2026'
  },
  {
    id: 'E-020', category: 'Rejected', status: 'Rejected', confidence: 'Low',
    claim: 'Delta definitively leads India-focused competitors in liquidity or reliability.',
    summary: 'No transparent, directly comparable and current public dataset was found that supports a defensible leadership claim across venues.',
    source: 'Competitive research gap and adversarial audit',
    url: 'downloads/delta-exchange-adversarial-audit.pdf#page=2',
    counter: 'Internal market-quality data or a rigorous independent venue dataset may support a narrower claim.',
    implication: 'Avoid superlatives without a defined metric, timeframe and comparable dataset.',
    updated: '20 Jul 2026'
  }
];
