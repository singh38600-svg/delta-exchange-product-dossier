window.DOSSIER_METRICS = {
  reviewCount: 22199,
  averageRating: 3.69,
  positiveShare: 65.7,
  negativeShare: 28.0,
  polarizedShare: 78.4,
  replyRate: 87.2,
  repeatedReviewText: 40.7,
  shortReviewShare: 53.3,
  complaintThemes: [
    {label:'Fees, brokerage and deductions', value:30.4, votes:5982},
    {label:'Lag, freezes and availability', value:18.2, votes:5815},
    {label:'P&L, balance and accounting', value:17.9, votes:5695},
    {label:'Orders, execution and stop-loss', value:16.4, votes:6622},
    {label:'Charts, candles and prices', value:11.7, votes:4560},
    {label:'Trust allegations', value:10.0, votes:2395},
    {label:'Deposits and withdrawals', value:8.7, votes:2231},
    {label:'Customer support', value:5.2, votes:1387}
  ],
  ratingDistribution: [
    {stars:1, count:5273, share:23.8},
    {stars:2, count:947, share:4.3},
    {stars:3, count:1404, share:6.3},
    {stars:4, count:2433, share:11.0},
    {stars:5, count:12142, share:54.7}
  ]
};
